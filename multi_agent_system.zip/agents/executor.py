from langchain.chat_models import ChatOpenAI
from tools import TOOLS

llm = ChatOpenAI(model="gpt-4o-mini")

def execute_task(plan):
    tool_result = ""
    if "搜索" in plan:
        tool_result = TOOLS["search"](plan)

    prompt = f"""
你是执行Agent:
计划:{plan}
工具:{tool_result}
输出执行结果:
"""
    return llm.predict(prompt)
