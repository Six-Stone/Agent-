from langchain.chat_models import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini")

def review_result(result):
    prompt = f"""
你是审核Agent:
优化结果:
{result}
"""
    return llm.predict(prompt)
