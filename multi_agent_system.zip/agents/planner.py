from langchain.chat_models import ChatOpenAI
from memory import get_recent_memory

llm = ChatOpenAI(model="gpt-4o-mini")

def plan_task(user_input):
    memory = get_recent_memory()
    prompt = f"""
你是规划Agent:
历史:{memory}
需求:{user_input}
输出步骤:
1.
2.
"""
    return llm.predict(prompt)
